const ENDPOINT = "https://2zhooj2lkk.execute-api.us-east-1.amazonaws.com/dev"

export default ENDPOINT;