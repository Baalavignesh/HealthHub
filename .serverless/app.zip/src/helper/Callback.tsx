// Process Authentication 
// Validate the token
// Set the token in redux